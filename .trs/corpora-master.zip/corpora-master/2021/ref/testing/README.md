# Testing data

This folder contains the testing data with reference annotations. Three separate sources are given: medline (Spanish), wikinews (Spanish), and CORD (English).
