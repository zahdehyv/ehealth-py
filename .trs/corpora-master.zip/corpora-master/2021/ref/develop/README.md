# Development data

This folder contains the development data and reference annotations for eHealthKD 2021. The development data consists of:

- 50 sentences from the CORD-19 corpus (English).
- 25 sentences from Medline (Spanish).
- 25 sentences from Wikinews (Spanish).

You can use the development data as an offline test set during the competition to evaluate your own ssytem, and you can further use it for fine-tuning before submitting your final approach(es) to the challenge.

