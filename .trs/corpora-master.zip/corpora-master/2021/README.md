# eHealth-KD 2021 Corpora

This folder contains the **training**, **development**, and **test** data of the eHealth-KD 2021 challenge.
Data will be released in due time.
Please check [the website](https://ehealthkd.github.io/2021) for more details.
