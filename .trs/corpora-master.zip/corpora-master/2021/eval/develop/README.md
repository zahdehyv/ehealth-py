# Development data

This folder contains the development data in evaluation format, i.e., divided by scenarios. All three scenarios have the same 100 sentences.
