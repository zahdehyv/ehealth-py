# eHealth-KD Corpora

Public corpora for the eHealth-KD challenges and related resources.
