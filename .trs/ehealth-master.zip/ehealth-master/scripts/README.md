# Evaluation Scripts and Baselines

This folder contains all the necessary scripts to load the data, run the baseline, and compute evaluation scores.

Please refer to [the submission instructions](https://knowledge-learning.github.io/ehealthkd-2020/submission) for more details.
