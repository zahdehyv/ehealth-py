# Training, Development and Test Data

This folder contains the training, development and test data for the eHealth-KD corpus.
Check the [submission instructions](https://knowledge-learning.github.io/ehealthkd-2020/submission) for details.

To use the eHealth-KD 2020 corpus you must agree to the license by [filling this form](https://forms.gle/pUJutSDq2FYLwNWQA).
