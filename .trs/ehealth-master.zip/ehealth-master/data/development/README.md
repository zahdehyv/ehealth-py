# Development data

This repository contains development data for cross-validation purposes.
The folder `main` contains 200 sentences in the Medline domain.
The folder `transfer` contains 100 sentences in the alternative domain (Wikinews) to evaluate transfer learning approaches.
